#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""【v2.0.0 新增环节】把 PPT / PPTX / DOC / DOCX / ODP 统一转成 PDF —— 视频管线的第 0 步。

为什么必须有这一步(2026-10-07 修复"画面跑偏"):
  旧流程让 PPT 直接进抽页图环节,靠 python-pptx 之类的库**按对象模型重排版面**。
  python-pptx 只读形状坐标,不做字体替换、不做自动换行、不做行高修正 ——
  一遇到"文本框比文字小/字体缺失/母版占位符没渲染",出来的图就跟 PowerPoint 里
  看到的不一样,表现为**画面跑偏、字压图、元素错位**。
  转 PDF 之后,排版由 LibreOffice 的完整排版引擎一次性定死(pdf 记的是绝对坐标),
  后续抽图只是"把 PDF 每页栅格化",**不再有任何重排**,跑偏从根上消失。

用法:
  python to_pdf.py --input "<file.pptx>" --job <JOBDIR> [--out source.pdf]
  python to_pdf.py --input "<file.pdf>"  --job <JOBDIR>     # 已是 PDF -> 直接登记,秒过

行为约定:
  - 输入已是 PDF  -> 幂等直通(复制/登记到 pdf/source.pdf),不碰 LibreOffice。
  - 输出的 PDF 落在 <JOBDIR>/pdf/source.pdf,作为**可留存的中间产物**,
    后续 pdf_to_pages.py 从这里读。默认保留(便于复跑、便于核对页数),
    要清就显式 --clean。
  - LibreOffice 的用户 profile 走临时目录,转换结束无论成败都删 —— 它体积大、
    留着会把工程目录撑脏。转换产物本身不删。

失败处理(全部是**明确报错 + 可执行的下一步**,绝不静默跳过、绝不产出半成品):
  1) 找不到 soffice      -> 报探测过的所有路径 + 安装/指路(--soffice 显式指定)
  2) soffice 非 0 退出   -> 打印 stderr 尾部 600 字 + 三条常见解法
  3) soffice 退出码 0 但没产出 PDF -> 明确说"转换没成功",并给出最大嫌疑(受保护/加密/损坏)
  4) 超时                 -> 杀掉进程组并报错,提示 --timeout 调大
  5) 产出 0 页            -> 报错(空 PDF 进下游会静默生成 0 段视频)
"""
import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from datetime import datetime

sys.stdout.reconfigure(encoding="utf-8")

# LibreOffice 支持的输入扩展名 -> 说明(只用来报错时给人看)
KNOWN = {
    ".pptx": "PowerPoint 2007+", ".ppt": "PowerPoint 97-2003",
    ".docx": "Word 2007+", ".doc": "Word 97-2003",
    ".odp": "OpenDocument 演示", ".ods": "OpenDocument 表格",
    ".rtf": "RTF", ".xlsx": "Excel 2007+", ".xls": "Excel 97-2003",
    ".pdf": "PDF(直通,不转换)",
}
PDF_EXT = ".pdf"


def die(msg, code=1):
    print("[错误] " + msg, file=sys.stderr)
    sys.exit(code)


def find_soffice(explicit=""):
    """按 PATH -> 常见安装目录 找 soffice,不写死任何一台机器的路径。

    Windows 上优先 soffice.com:soffice.exe 是 GUI 启动器,调用后会**立刻返回**,
    不等转换完成 -> 表现为"exit 0 但文件还没生成"。soffice.com 是控制台版,
    会阻塞到真正跑完。踩过这个坑,别改回去。
    """
    if explicit:
        if os.path.exists(explicit):
            return explicit
        die("指定的 --soffice 不存在: %s" % explicit)

    env = os.environ.get("SOFFICE_PATH", "").strip()
    cands = []
    if env:
        cands.append(env)
    for name in ("soffice.com", "soffice.exe", "soffice", "libreoffice"):
        w = shutil.which(name)
        if w:
            cands.append(w)
    cands += [
        "C:/Program Files/LibreOffice/program/soffice.com",
        "C:/Program Files/LibreOffice/program/soffice.exe",
        "C:/Program Files (x86)/LibreOffice/program/soffice.com",
        "C:/Program Files (x86)/LibreOffice/program/soffice.exe",
        "/usr/bin/soffice", "/usr/local/bin/soffice", "/snap/bin/libreoffice",
        "/Applications/LibreOffice.app/Contents/MacOS/soffice",
    ]
    for c in cands:
        if c and os.path.exists(c):
            return c
    return ""


def page_count(pdf):
    """数页数。优先 pymupdf,没有就退回正则数 /Type /Page。都失败返回 0(调用方按未知处理)。"""
    try:
        import pymupdf
        with pymupdf.open(pdf) as d:
            return d.page_count
    except Exception:
        pass
    try:
        with open(pdf, "rb") as f:
            blob = f.read()
        n = len(re.findall(rb"/Type\s*/Page[^s]", blob))
        m = re.findall(rb"/Count\s+(\d+)", blob)
        if m:
            return max(n, int(max(m, key=lambda x: int(x))))
        return n
    except Exception:
        return 0


def file_stable(p, quiet_ms=1200, timeout=30):
    """等文件大小连续 quiet_ms 不变 -> 认为写完了(soffice 是异步落盘的)。"""
    t0 = time.time()
    last, last_t = -1, time.time()
    while time.time() - t0 < timeout:
        if os.path.exists(p):
            sz = os.path.getsize(p)
            if sz > 0 and sz == last:
                if (time.time() - last_t) * 1000 >= quiet_ms:
                    return True
            else:
                last, last_t = sz, time.time()
        time.sleep(0.3)
    return os.path.exists(p) and os.path.getsize(p) > 0


def convert(src, out_pdf, soffice, timeout, profile):
    """跑一次 headless 转换。返回 (ok, 详细原因)。不抛异常,原因交给上层报错。"""
    outdir = os.path.dirname(out_pdf)
    os.makedirs(outdir, exist_ok=True)
    # 独立 profile:避免和用户正在开的 LibreOffice 抢同一份配置(会直接拒绝转换)
    purl = "file:///" + profile.replace("\\", "/").lstrip("/")
    cmd = [
        soffice,
        "-env:UserInstallation=%s" % purl,
        "--headless", "--norestore", "--invisible", "--nolockcheck", "--nodefault",
        "--convert-to", "pdf:impress_pdf_Export",
        "--outdir", outdir, src,
    ]
    flags = {}
    if os.name == "nt":
        flags["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        cp = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8",
                            errors="replace", timeout=timeout, **flags)
    except subprocess.TimeoutExpired:
        return False, "soffice 转换超时(>%ss)。大 PPT/多图 PPT 转 PDF 可能要几分钟," \
                      "用 --timeout 600 调大。" % timeout
    except Exception as e:  # 启动失败等
        return False, "拉起 soffice 失败: %r" % (e,)

    produced = os.path.join(outdir, os.path.splitext(os.path.basename(src))[0] + PDF_EXT)
    if cp.returncode != 0:
        return False, "soffice 退出码 %d\n%s" % (
            cp.returncode, ((cp.stderr or cp.stdout or "").strip()[-600:] or "(无输出)"))
    if not os.path.exists(produced) or os.path.getsize(produced) == 0:
        # exit 0 却没文件:soffice 对"加密/受保护/已损坏"的文档会这么干
        return False, ("soffice 退出码 0 但没产出 PDF。常见原因:"
                       "① 文档加密/只读/受保护 ② 文档损坏 ③ 文件被 WPS/Office 独占锁着"
                       "—— 先用 Office/WPS 手动另存一份,或关掉占用它的程序再试。")
    if not file_stable(produced):
        return False, "PDF 落盘未稳定(等了 30s 文件大小还在变),可能是磁盘慢或转换被中断。"
    if os.path.abspath(produced) != os.path.abspath(out_pdf):
        if os.path.exists(out_pdf):
            os.remove(out_pdf)
        shutil.move(produced, out_pdf)
    return True, ""


def main():
    ap = argparse.ArgumentParser(description="PPT/文档 -> PDF(v2.0.0 新增管线环节)")
    ap.add_argument("--input", required=True, help="源文件(.pptx/.ppt/.docx/.pdf ...)")
    ap.add_argument("--job", default=".", help="工程目录,pdf/ 会建在它下面")
    ap.add_argument("--out", default=os.path.join("pdf", "source.pdf"),
                    help="输出路径(相对 --job),默认 pdf/source.pdf —— 与 pdf_to_pages.py 的默认值对齐")
    ap.add_argument("--soffice", default="", help="显式指定 soffice 路径(探测不到时用)")
    ap.add_argument("--timeout", type=int, default=300, help="转换超时秒数,默认 300")
    ap.add_argument("--clean", action="store_true",
                    help="转换并抽图后删掉 pdf/ 目录(默认保留中间产物)")
    ap.add_argument("--force", action="store_true", help="已有 PDF 也重转")
    a = ap.parse_args()

    src = os.path.abspath(a.input)
    if not os.path.exists(src):
        die("找不到输入文件: %s" % src)
    job = os.path.abspath(a.job)
    os.makedirs(job, exist_ok=True)
    out_pdf = os.path.join(job, a.out)
    ext = os.path.splitext(src)[1].lower()
    t0 = time.time()

    # --- 幂等:已是 PDF 就直接登记,压根不碰 LibreOffice ---
    if ext == PDF_EXT:
        if os.path.abspath(src) != os.path.abspath(out_pdf):
            os.makedirs(os.path.dirname(out_pdf), exist_ok=True)
            if os.path.exists(out_pdf) and not a.force:
                pass
            else:
                shutil.copyfile(src, out_pdf)
        n = page_count(out_pdf)
        print("[直通] 输入已是 PDF,跳过转换 -> %s(%s 页)" % (out_pdf, n if n else "?"))
        _write_meta(job, out_pdf, src, "passthrough", n, time.time() - t0)
        if a.clean:
            _rm(out_pdf)
        print("下一步:python pdf_to_pages.py --job <JOBDIR> --pdf %s --outdir pages" % a.out)
        return

    if ext not in KNOWN:
        print("[提醒] %s 不在常见办公扩展名里(%s),照样试着转,失败会报错。"
              % (ext, "、".join(sorted(KNOWN))), file=sys.stderr)

    # --- 已有产物且不比源文件旧 -> 跳过(改 PPT 后会自动重转,因为 mtime 变新)---
    if os.path.exists(out_pdf) and not a.force:
        if os.path.getmtime(out_pdf) >= os.path.getmtime(src):
            n = page_count(out_pdf)
            print("[跳过] %s 已是最新(不比源文件旧)。要重转加 --force" % a.out)
            _write_meta(job, out_pdf, src, "cached", n, 0.0)
            if a.clean:
                _rm(out_pdf)
            return

    soffice = find_soffice(a.soffice)
    if not soffice:
        die("找不到 LibreOffice(soffice),没法把 %s 转成 PDF。\n"
            "  装 LibreOffice: https://www.libreoffice.org/download/\n"
            "  或用 Office/WPS 手动另存为 PDF,然后直接跑:\n"
            "    python pdf_to_pages.py --input \"<手动导出的.pdf>\" --outdir pages\n"
            "  实在不想装,用 --soffice \"<soffice 完整路径>\" 显式指一下(已探测过:%s)"
            % (ext, "、".join(["PATH", "C:/Program Files/LibreOffice/program", "/usr/bin",
                               "/Applications/LibreOffice.app"])))

    tmpdir = tempfile.mkdtemp(prefix="_lo_profile_")
    try:
        ok, why = convert(src, out_pdf, soffice, a.timeout, tmpdir)
    finally:
        # profile 目录必删:体积大、且和转换结果无关,留着只会把工程目录撑脏
        shutil.rmtree(tmpdir, ignore_errors=True)

    if not ok:
        die("PPT -> PDF 转换失败。\n原因:%s\n"
            "  这一步是整条管线的地基(排版在这里被定死),**没有 PDF 就没有视频** —— "
            "不要跳过它。" % why)

    n = page_count(out_pdf)
    if n == 0:
        # 宁可报错也不能让 0 页 PDF 流下去:后面会静默生成一个 0 段的空视频
        _rm(out_pdf)
        die("转换出来的 PDF 读不出页数(疑似 0 页/加密/损坏),已删除该产物。"
            "请用 Office/WPS 手动另存一份 PDF 再跑 pdf_to_pages.py。")

    sz = os.path.getsize(out_pdf) / 1048576.0
    _write_meta(job, out_pdf, src, "libreoffice", n, time.time() - t0)
    print("[完成] %s -> %s(%d 页, %.1f MB, %.1fs)" % (ext, out_pdf, n, sz, time.time() - t0))
    if a.clean:
        _rm(out_pdf)
        print("[清理] 已按 --clean 删除中间 PDF")
    else:
        print("[保留] 中间产物 %s(要复跑/核对页数就留着;确认无误可 --clean 删掉)" % a.out)
    print("下一步:python pdf_to_pages.py --job <JOBDIR> --pdf %s --outdir pages" % a.out)


def _rm(p):
    try:
        os.remove(p)
    except OSError as e:
        print("[警告] 删不掉 %s: %s" % (p, e), file=sys.stderr)


def _write_meta(job, out_pdf, src, how, pages, secs):
    """留一份来源记录:成片出问题时要能回头查"这页图是从哪个文件的第几页来的"。"""
    m = {
        "source_file": src,
        "source_ext": os.path.splitext(src)[1].lower(),
        "pdf": out_pdf,
        "converter": how,
        "pages": pages,
        "elapsed_sec": round(secs, 2),
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "skill_version": "2.0.0",
    }
    p = os.path.join(job, "pdf", "source.json")
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(m, f, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    main()