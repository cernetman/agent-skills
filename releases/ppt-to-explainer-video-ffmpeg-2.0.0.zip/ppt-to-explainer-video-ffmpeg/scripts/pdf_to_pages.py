#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""【v2.0.0】PDF -> pages/NN.png + source.txt —— 视频管线的第 1 步(取代旧的 doc-to-pages.mjs)。

为什么这个脚本存在(2026-10-07):
  旧 SKILL.md 第 1 步写的是"复用 ppt-explain 专家的 doc-to-pages.mjs",但那个技能
  **本机根本没装**,于是每次都得手工兜底,兜底方式还各不相同 -> 抽出来的页图尺寸/比例
  参差不齐,下游 render_all.py 一律 scale+pad 到 1920x1080,画面就跟着跑偏。
  现在把这一步固化成本仓库里的脚本:**输入只有 PDF**,页图比例由 PDF 唯一决定。

与旧步骤的输出契约完全一致(下游 render_all.py / gen_sentence_ass.py 一行都不用改):
  <outdir>/01.png ... NN.png     抽出的页图
  source.txt                     逐页文本,供写旁白时对着看

用法:
  python pdf_to_pages.py --job <JOBDIR> [--pdf pdf/source.pdf] [--input x.pdf] [--outdir pages]
"""
import argparse
import json
import os
import sys

sys.stdout.reconfigure(encoding="utf-8")

DEFAULT_PDF = os.path.join("pdf", "source.pdf")


def die(msg, code=1):
    print("[错误] " + msg, file=sys.stderr)
    sys.exit(code)


def resolve_pdf(job, a):
    """先按 --pdf,再按 --input,最后落到 <job>/pdf/source.pdf。

    允许 --input 直接指 PDF:用户手动用 Office/WPS 导出的 PDF 也能一步进管线,
    不用先手工搬进 pdf/ 目录。
    """
    if a.input:
        p = os.path.abspath(a.input)
        if not os.path.exists(p):
            die("找不到输入 PDF: %s" % p)
        return p
    p = os.path.join(job, a.pdf)
    if not os.path.exists(p):
        # 给人话:上一步该跑什么
        die("找不到 %s —— 先把源文件转成 PDF(v2.0.0 新增的第 0 步):\n"
            "    python to_pdf.py --input \"<你的.pptx>\" --job .\n"
            "  已经是 PDF 的话,直接 --input \"<那个.pdf>\" 也行。" % a.pdf)
    return p


def main():
    ap = argparse.ArgumentParser(description="PDF -> 逐页 PNG + 文本(v2.0.0)")
    ap.add_argument("--job", default=".")
    ap.add_argument("--pdf", default=DEFAULT_PDF, help="相对 --job 的 PDF 路径")
    ap.add_argument("--input", default="", help="直接给 PDF 绝对/相对路径(优先于 --pdf)")
    ap.add_argument("--outdir", default="pages", help="页图输出目录,相对 --job")
    ap.add_argument("--dpi", type=int, default=144,
                    help="栅格化精度。144dpi 对 16:9 版心≈1920x1080,默认即可;要 4K 传 288")
    ap.add_argument("--scale-to", default="",
                    help="强制长边像素(如 1920)。给了就按它缩,忽略 dpi")
    ap.add_argument("--min-dpi", type=int, default=0,
                    help="保底精度:PDF 页面本身很小时用它兜底,避免抽出小图再被放大糊掉")
    a = ap.parse_args()

    job = os.path.abspath(a.job)
    pdf = resolve_pdf(job, a)
    outdir = os.path.join(job, a.outdir)
    os.makedirs(outdir, exist_ok=True)

    try:
        import pymupdf  # PyMuPDF >= 1.24;老版本叫 fitz
    except ImportError:
        try:
            import fitz as pymupdf  # 兼容老 API
        except ImportError:
            die("缺 pymupdf,抽不了页图。装它:\n"
                "    <你的python.exe>/pip install pymupdf\n"
                "  (注意:本机 PATH 里的 python3 不一定装了包,用 precheck.mjs 给你挑好的那个)")
    except Exception as e:
        die("import pymupdf 时报错: %r" % (e,))

    try:
        doc = pymupdf.open(pdf)
    except Exception as e:
        die("打不开 PDF %s: %r\n  常见于加密/损坏 —— 先用 Office/WPS 重新导一份。" % (pdf, e))

    if doc.needs_pass:
        die("这个 PDF 有打开密码,抽不了页图。先去掉密码再导出。")

    n = doc.page_count
    if n == 0:
        die("PDF 0 页,抽不出页图。")

    zoom = a.dpi / 72.0
    wrote, texts = [], []
    for i, page in enumerate(doc, start=1):
        tag = "%02d" % i
        pm = page.get_pixmap(matrix=pymupdf.Matrix(zoom, zoom), alpha=False)
        w, h = pm.width, pm.height
        need = max(w, h)
        z2 = zoom
        if a.scale_to:
            # 强制长边到 --scale-to:按比例放大/缩小到目标像素
            z2 = float(a.scale_to) / need if need else zoom
        elif a.min_dpi and need < a.min_dpi:
            # 页面本身小(A5 竖版之类)-> 提到保底长边,别抽小图让下游放大变糊
            z2 = zoom * (float(a.min_dpi) / need)
        if abs(z2 - zoom) > 1e-6:
            pm = page.get_pixmap(matrix=pymupdf.Matrix(z2, z2), alpha=False)
        p = os.path.join(outdir, tag + ".png")
        pm.save(p)
        wrote.append((tag, pm.width, pm.height))
        t = page.get_text("text").strip()
        texts.append("===== 第 %d 页 =====\n%s" % (i, t if t else "(无文本层)"))
        print("[抽页] %s  %dx%d  %s" % (tag, pm.width, pm.height,
                                       "有文本" if t else "无文本层"), flush=True)

    # source.txt:写旁白时逐页对照用。分段符和旧 doc-to-pages 一致。
    src_txt = os.path.join(job, "source.txt")
    with open(src_txt, "w", encoding="utf-8") as f:
        f.write("\n\n".join(texts) + "\n")

    doc.close()

    # 比例一致性体检:比例不一致 -> 下游 pad 会留黑边,观感就是"画面跑偏"。
    # 这里只提示不阻断(有的 PPT 本来就混排不同比例),但要让人看见。
    ratios = {}
    for tag, w, h in wrote:
        ratios.setdefault(round(w / h, 3), []).append(tag)
    warn = ""
    if len(ratios) > 1:
        detail = "; ".join("%.3f(%s)" % (k, ",".join(v[:6]) + ("..." if len(v) > 6 else ""))
                           for k, v in sorted(ratios.items(), reverse=True))
        warn = ("\n[提醒] 本 PDF 存在 %d 种页面比例:%s\n"
                "       下游会统一 scale+pad 到 1920x1080,不同比例的页会带黑边。"
                "若这是源 PPT 本身混排所致,属预期;若本该同比例,回头查 PPT 母版设置。"
                % (len(ratios), detail))

    meta = os.path.join(job, "pdf", "pages_meta.json")
    os.makedirs(os.path.dirname(meta), exist_ok=True)
    with open(meta, "w", encoding="utf-8") as f:
        json.dump({"pdf": pdf, "pages": len(wrote),
                   "size": {t: [w, h] for t, w, h in wrote},
                   "ratios": {str(k): v for k, v in ratios.items()}},
                  f, ensure_ascii=False, indent=2)

    print("\n完成:%d 页 -> %s" % (len(wrote), outdir))
    print("文本 -> %s(逐页对照写旁白)" % src_txt)
    print("尺寸分布 -> %s" % meta)
    if warn:
        print(warn)
    print("\n下一步:在 vo3/ 里写 NN.txt 逐页旁白,然后跑 gen_sentence_ass.py")


if __name__ == "__main__":
    main()