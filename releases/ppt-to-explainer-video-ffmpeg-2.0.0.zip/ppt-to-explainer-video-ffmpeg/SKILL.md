---
name: ppt-to-explainer-video-ffmpeg
display_name: PPT 转逐页讲解视频（ffmpeg 本地版）
display_name_en: PPT to Page-by-Page Explainer Video (Local ffmpeg)
description: 把 PPT/PDF/文档做成「逐页讲解视频」（页图 + 讲师旁白 + 硬字幕 + 转场），调用 edge-tts 合成中文旁白，用本机 ffmpeg 渲染，不依赖任何在线转写服务、不上传素材。v2.0.0 起输入链路固定为 PPT→PDF→页图→视频（先经 LibreOffice 转 PDF 定死排版，消除画面跑偏）。支持静态逐句字幕与从右往左滚动跑马灯两种形态，可加片头卡片与末页定格。当用户说「把这份 PPT 做成讲解视频/讲课视频/带旁白的视频」「配字幕的逐页视频」「给课件配个口播」时使用。
description_zh: 用本机 ffmpeg 把 PPT/PDF 逐页转成带 AI 旁白和硬字幕的讲解视频。v2.0.0 起先统一转 PDF 再抽页图，排版不再跑偏；全部离线渲染，无需在线转写服务。
description_en: Turn a PPT/PDF into a page-by-page explainer video with AI narration and burned-in subtitles, rendered fully locally with ffmpeg. Since v2.0.0 all input goes through a PDF normalization step, so page layout can no longer drift.
version: 2.0.0
author: zhangjw
category: office
agent_created: true
---

# PPT → 逐页讲解视频（ffmpeg 本地版）

> **v2.0.0（2026-10-07）重大升级**：输入链路改为 **PPT → PDF → 页图 → 视频**。
> PPT 先经 LibreOffice 转成 PDF，排版由排版引擎一次性定死，再栅格化成页图，
> **从根上消除「画面跑偏」**。旧文档引用的 `ppt-explain` 技能本机并未安装，已用本仓库 `pdf_to_pages.py` 取代。
> 第 2–7 步（写旁白 / 配音 / 渲染 / 字幕 / 合成 / 校验）**完全未变**。详见文末「版本历史」。

## 何时用
用户给一份 PPT/PDF/文档，要「逐页讲解视频 + 讲师旁白 + 字幕」。
**目标时长先问清**（如 4 分钟精华版 ≈ 1000 字旁白，按 250 字/分钟折算）。

**别用它**：离线/内网（edge-tts 要联网）、扫描件无文本 PPT、要保留原 PPT 动画、多语种。

## 架构：三段式（2026-10-02 重构，性能实测）

旧做法是「每段各烧各的字幕 → 套 N-1 级 xfade 拼接」。50 页实测 **65s + 63s = 128s**，而且每加一级 xfade 都重编一遍全片、像素一代代掉质量。

新做法把**字幕烧录**和**转场拼接**解耦：

```
① 段渲染(不带字幕,并行 j=4)  →  seg/NN.mp4  +  durations2.txt
② -f concat -c copy 硬切     →  master.mp4（0 重编码）
③ 单遍烧 all.ass             →  成片.mp4（唯一一次全片重编码）
```

### 性能实测（50 页 / 1920×1080 / 30fps，本机 i9-13900HX）

| 环节 | 旧架构 | 新架构（medium 定稿） | 新架构（veryfast 定稿） |
|---|---|---|---|
| 段渲染 | 65 s（串行、段内烧字幕） | 41.7 s（并行 j=4、不烧字幕） | 41.7 s |
| 拼接 | 63 s（49 级 xfade） | 1.4 s（`-c copy` 硬切） | 1.4 s |
| 烧字幕 | 含在段渲染里 | 47.5 s（crf20 medium） | 34.8 s（crf20 veryfast） |
| **合计** | **128 s** | **90.6 s（-29%）** | **77.9 s（-39%）** |

**并行是最大单项收益**：同样不烧字幕，`--j 1` 58.8 s vs `--j 4` 41.7 s（**-29%**）。

### 整片回归（2026-10-02，宽泽生态 50 页实片对比）

| 指标 | 旧架构成片 | 新架构成片 | 说明 |
|---|---|---|---|
| 时长 | 464.5 s | 492.1 s | 硬切不吃转场时间，各页按语音长度走 |
| 体积 | 119.5 MB | 47.9 MB | **只有旧版 40%** |
| 码率 | 2059 kbps | 778 kbps | 画面以静态图文为主，此码率实测文字清晰 |
| 渲染总耗时 | 128 s | 42.1 s（段渲染）+ 1.4 s（拼接）+ 49 s（烧字幕）≈ **93 s（-27%）** | |
| 音频 | aac ✓ | aac ✓（concat `-c copy` 后未丢） | |

回归抽帧抽查通过：片头 3s（纯文字公司名）、中段滚动字幕在滚、末页定格 3s、无黑屏/音画错位。

**额外收益**：`master.mp4` 是无字幕母版——改片头、换字幕版（静态↔滚动）都**不必重新配音、不必重渲段**，只重烧一遍；加 3 秒片头走 `-c copy` 直拼，不用重编整片。

> 想保留交叉淡入的观感：给每段多渲 0.5s 前后余量，或最后一步用 `--mode xfade`（兼容旧流程）。

## 环境前提（本机已具备）

先跑自检，别一上来就硬干：

```bash
node "<技能目录>/scripts/precheck.mjs" --job "<JOBDIR>" --minutes <预计分钟>
```

- **ffmpeg / ffprobe / 中文字体全部自动探测，不写死任何机器路径**：`precheck.mjs` 按 `PATH → /usr/bin → /usr/local/bin → 常见安装目录 → ~/bin` 依次找，Windows 上还会找 `C:/Windows/Fonts/simhei.ttf`、Linux 找文泉驿/Noto CJK、macOS 找 PingFang。**换机器照样能跑**，需要时用 `--ff` / `--font` / `--ffprobe` 显式指定。
- **Python 解释器有坑**：PATH 里的 `python3` 可能是**没装 edge_tts** 的那个版本（本机 3.14.3 就没装，3.13.12 才装着）。`precheck.mjs` 会把候选解释器（`where python` + 托管 python 各版本）逐个试一遍 `import edge_tts`，挑中能用的那个告诉你；也可 `--py <python.exe>` 直给。
- **v2.0.0 新增依赖**（第 0、1 步要用）：
  - **LibreOffice**（`soffice`）：只有源文件是 PPT/Word/表格时才需要。装不上也能跑 —— 用 Office/WPS 手动另存 PDF 直接进第 1 步。下载地址 https://www.libreoffice.org/download/
  - **pymupdf**（`pip install pymupdf`）：第 1 步抽页图强依赖，新 API 是 `import pymupdf`，老版本 `import fitz` 脚本两个都试。
  - ⚠️ `pymupdf` 必须和 `edge_tts` **装在同一个解释器**里，否则会出现「第 0 步转出 PDF 了、第 1 步却抽不出图」的半路断链。`precheck.mjs` 会分别指出装在哪个解释器上。
- 页图来源：**ffmpeg 常不带 PDF 解码器** → 本技能固定走 pymupdf 抽图（不再依赖 ffmpeg 解 PDF）。

## 输入链路：PPT → PDF → 页图 → 视频（v2.0.0 起强制）

```
<file.pptx>  ──[0] to_pdf.py(LibreOffice)──►  pdf/source.pdf
                                                │
<file.pdf>  ─────────────────────────────────────┤  直通,不转换
                                                ▼
                                            [1] pdf_to_pages.py(pymupdf)
                                                ▼
                                        pages/NN.png + source.txt
                                                ▼
                                        [2~7] 配音/渲染/字幕/合成  ←── 以下完全没变
```

**为什么中间必须垫一层 PDF（这是 v2.0.0 的全部动机）**：
旧流程让 PPT 直接进抽页图环节，靠 python-pptx 之类的库按**形状对象模型**重排版面。这类库只读坐标，不做字体替换、不做自动换行、不做行高修正。一遇到"文本框比文字小 / 字体缺失 / 母版占位符没渲染"，抽出来的图就跟 PowerPoint 里看到的不一样 —— 表现为**画面跑偏、字压图、元素错位**。

转成 PDF 之后，排版由 LibreOffice 完整排版引擎**一次性定死**（PDF 记的是绝对坐标），第 1 步只是"把每页栅格化成 PNG"，**不再有任何重排环节**，跑偏从根上消失。

**代价**：多一次转换（本机 50 页 PPT 实测 25–40 s）。换来的是 50 页页图比例 100% 一致（实测统一 1921×1080，单一比例），下游 `render_all.py` 的 scale+pad 不再产生黑边。

### 输入支持范围

| 输入 | 第 0 步行为 |
|---|---|
| `.pptx / .ppt` | LibreOffice 转 PDF（Impress 引擎） |
| `.docx / .doc / .rtf / .odp` | LibreOffice 转 PDF |
| `.pdf` | **直通**：直接登记，压根不碰 LibreOffice，秒过 |
| `.xlsx / .xls` | LibreOffice 转 PDF（每 sheet 一页，慎用） |

## 管线（8 步：0 转 PDF → 7 校验）

### 0. 转 PDF（v2.0.0 新增，PPT/Word 必做）
```bash
"<你的python.exe>" "<技能>/scripts/to_pdf.py" --input "<file.pptx>" --job .
```
- 产出 `pdf/source.pdf`（+ `pdf/source.json` 记来源/页数/耗时，便于回溯"这页图来自哪个文件第几页"）。
- **幂等**：产物不比源文件旧就跳过；改过 PPT 会自动重转。`--force` 强制。
- **失败不兜底、不降级**：soffice 找不到 / 非 0 退出 / 退出码 0 却没产出 / 超时 / 产出 0 页 —— 五种情况各自报错并给出下一步，**绝不产出半成品**。这一步是整条管线的地基，没有 PDF 就没有视频，不要试图跳过它。
- 已拿到 PDF 的工程**不需要装 LibreOffice**，直接进第 1 步。
- 详细失败码与排障见下方「第 0 步失败处理」。

### 1. PDF → 页图 + 文本
```bash
"<你的python.exe>" "<技能>/scripts/pdf_to_pages.py" --job . --outdir pages
```
- 输入**只有 PDF**（v2.0.0 起本页图来源被钉死，这是消除跑偏的关键）。
- 产出 `01.png…NN.png` + `source.txt`（逐页文本，写旁白时对照用）+ `pdf/pages_meta.json`（每页尺寸）。
- 默认 144dpi ≈ 1920×1080；`--scale-to 1920` 强制长边，`--min-dpi` 给小页面保底。
- **比例体检**：脚本会统计所有页的宽高比，混排多种比例时**只警告不阻断**（源 PPT 本就混排属预期），但会明确告诉你哪几页比例不同。
- ⚠️ 本机 ffmpeg **无 PDF 解码器**，所以这一步用 pymupdf，不用 ffmpeg。

> **别再退回 python-pptx 直接抽 PPT** —— 那正是 v2.0.0 要消灭的跑偏来源。
> 旧文档引用的 `ppt-explain/scripts/doc-to-pages.mjs` **已废弃**：该技能本机并未安装，
> 旧流程每次都要手工兜底且兜法不一。v2.0.0 用本仓库的 `pdf_to_pages.py` 取代它。

### 2. 写旁白（每页一个 `vo3/NN.txt`）
口语化、TTS 友好：**数字保留阿拉伯数字**。总字数 ≈ 目标秒数 × 4.2。封面/过渡页 45-70 字，要点页 75-100 字。**先做字数自检（±20%）**。

### 3. 配音 + 字幕（一步做完，脚本 `gen_sentence_ass.py`）
```bash
"<你的python.exe>" "<技能>/scripts/gen_sentence_ass.py" --job . --in vo3 --out mp3 \
    --assdir ass --bounds bounds_cache.json --mode scroll --size 60 --y 900
```
- **一次流里既写 mp3 又收 `SentenceBoundary` 边界**，天然同步，不用调两次 TTS；边界落成 `bounds_cache.json`，后面换字幕版不再配音。
- 已有 `NN.mp3` 自动跳过（加 `--force` 强制重配）。
- 输出 `mp3/NN.mp3` + `ass/NN.ass` + `bounds_cache.json`。

### 4. 分段渲染（并行，脚本 `render_all.py`）
```bash
"<你的python.exe>" "<技能>/scripts/render_all.py" --job . --seg seg --rows durations.json \
    --durations-out durations2.txt --no-sub --j 4 --crf 23 --preset veryfast --tail-freeze 3.0
```
- `--no-sub`（默认）：段不带字幕，走三段式。
- `--tail-freeze 3.0`：最后一页尾部定格。
- 产出 `seg/NN.mp4` + `durations2.txt`（`NN=秒`）。
- 缺页面图/配音会直接报是哪个文件，不是静默跳过。

### 5. 生成整片字幕（脚本 `gen_film_ass.py`）
```bash
"<你的python.exe>" "<技能>/scripts/gen_film_ass.py" --job . --durations durations2.txt \
    --bounds bounds_cache.json --out all.ass --mode scroll --size 60 --y 900
```
时间轴（与 xfade 补偿等价）：**页面 i 起始 = Σ_{j<i} (dur_j − T)**。`--intro 2.5` 用于预挂了 3 秒片头的情况。

### 6. 合成成片（脚本 `gen_final.mjs`）
```bash
node "<技能>/scripts/gen_final.mjs" --job . --mode concat --seg seg --ass all.ass \
    --out 成片.mp4 [--intro intro/intro.mp4 --intro-dur 3.0]
```
然后**用 Bash 工具**执行它写出的 `render_final.sh`。

### 7. 校验 + 交付
```bash
ffprobe -v error -show_entries format=duration,size -of default=nw=1 成片.mp4
ffmpeg -y -ss <中段秒数> -i 成片.mp4 -frames:v 1 -update 1 -q:v 2 _check.png
```
用 Read 工具**看图**确认字幕不溢出、不遮挡。**再抽 1 帧确认画面没跑偏**
（v2.0.0 起这一项是必查：跑偏的根因已在前两步消除，但成片仍要眼见为实）。
再生成独立字幕：
```bash
node "<技能>/scripts/gen_srt.mjs" --job . --bounds bounds_cache.json --intro 2.5
```
最后：复制成片 + srt 到桌面交付，并 `present_files`。

## 脚本清单

| 脚本 | 语言 | 作用 | 主要参数 |
|---|---|---|---|
| `precheck.mjs` | node | 开工前环境自检（ffmpeg/ffprobe/字体/edge_tts/pymupdf/LibreOffice/源PDF/页图/磁盘预算） | `--job --ff --font --py --soffice --pdf --minutes` |
| `to_pdf.py` | py | **【v2.0.0 新增·第 0 步】** PPT/Word/表格 → PDF（LibreOffice headless），PDF 直通幂等 | `--input --job --out --soffice --timeout --clean --force` |
| `pdf_to_pages.py` | py | **【v2.0.0 新增·第 1 步】** PDF → `pages/NN.png` + `source.txt`（pymupdf），含比例体检 | `--job --pdf --input --outdir --dpi --scale-to --min-dpi` |
| `gen_sentence_ass.py` | py | 配音 + 逐句/滚动字幕（合并旧 3、4 步） | `--in --out --assdir --bounds --mode --voice --rate --size --y --force` |
| `render_all.py` | py | 并行段渲染 + 导出时长表 | `--seg --rows --durations-out --j --no-sub --burn-sub --crf --preset --tail-freeze` |
| `gen_film_ass.py` | py | 整片 ASS（绝对时间轴，支持 scroll/static） | `--durations --bounds --txt-dir --out --mode --size --y --w --h --intro --t` |
| `gen_final.mjs` | node | 合成成片（concat 三段式 / xfade 旧流程） | `--mode --seg --ass --durations --out --master --intro --intro-t --preset --crf --transition` |
| `gen_ass.mjs` | node | 逐页静态 ASS（旧流程兼容） | `--job --outdir --size --font --border --align --mv --mode` |
| `gen_srt.mjs` | node | 独立 SRT（默认逐句级，含片头偏移） | `--durations --bounds --src-dir --out --intro --t --source` |

## 关键参数速查
| 项 | 值 |
|---|---|
| 画幅 | `--w 1920 --h 1080`（横屏）/ `1080 1920`（竖屏） |
| 帧率 | 30 |
| 转场 | xfade fade 0.5s + acrossfade 0.5s（旧 `--mode xfade`）；新架构用硬切 + 字幕时间轴 |
| 字幕（静态逐句） | SimHei 40-46px，白字 + **BorderStyle 3**（`&HCC000000` 半透明黑底），Alignment=2，MarginV=90 |
| 字幕（滚动跑马灯） | SimHei 60px，白字黑描边，`\an7\q2` + `WrapStyle: 2`，`\move(屏宽, Y, -文本宽×1.06, Y, 0, 该页语音毫秒)` |
| 旁白音色 | zh-CN-XiaoxiaoNeural（男声 `zh-CN-YunxiNeural`） |
| 语速折算 | 实测 Xiaoxiao 默认 ≈4.5 字/秒；`--rate +11%` 后 ≈4.8 字/秒 |
| 抽页图 | 固定 **LibreOffice 转 PDF + pymupdf 抽图**（v2.0.0 起不再用 python-pptx 直接抽 PPT） |

## 字幕三形态（别搞混）

| 形态 | 关键设置 | 用在哪 |
|---|---|---|
| **静态逐句** | `WrapStyle: 0`，多条 `Dialogue` 按语音边界 | 常规讲解片、信息页 |
| **滚动跑马灯** | `\q2` + `WrapStyle: 2` + `\move` | 要"字幕随语音走完"的演示片 |
| **竖屏补硬字幕** | SimHei 62px、Alignment=2、MarginV≈240 | 1080×1920 分镜自带底部字幕条 |

⚠️ **`\q1` 不是不换行！** `\q1`=行尾换行模式，libass 对无空格中文长句仍按屏宽折行（实测 25 字折成 3 行堆叠）。滚动字幕必须用 `\q2` + 头部 `WrapStyle: 2` **双保险**。静态逐句才用 `WrapStyle: 0`（要自动换行）。

## 本机铁律（本技能反复依赖）
- **Node spawn 外部进程会被沙箱挡**（EBUSY / 无输出）→ 调 ffmpeg、跑 python 一律用 **Bash 工具**。Node 脚本只做「读文件 + 拼命令 + 写文件」。
- ffmpeg / python / ffprobe 在 Bash 里跑正常，长任务配 `dangerouslyDisableSandbox: true`。
- **批量渲染/拼接超过 2 分钟一律挂后台**（`run_in_background`），前台会被 SIGTERM 掐断。
- **Windows 盘符冒号在 ffmpeg filter 里转义无效**：`subtitles='C\:/x/01.ass'` 报 `Unable to parse "original_size"` → 先 `cd` 到目录再用相对名 `subtitles='01.ass'`（`-i` 的图/音仍用绝对路径）。
- **删文件用 Node `fs.unlinkSync`**（`Remove-Item` 不可靠）。
- **Bash 工具偶发 `sandbox-center cmd decisionRecord missing actual resource subject`**：同命令原样重跑通常即恢复；实在不行换 `node.exe <绝对路径脚本>` 这种不带 `VAR=...;` 前缀的写法。

## 踩坑清单（按踩的时间顺序）

1. **多行文案 → ASS 破损**：把 `\n` 直接拼进 Dialogue 行，第二行缺 `Dialogue:` 头，libass 解析失败 → **该页字幕整条消失还报成功**。修：逐行 `esc()` 后用字面的 `\N` 连接。**顺序不能反**——先拼 `\N` 再整体 esc 会变成 `\\N`（字面反斜杠+字母N）。
2. **样式默认值**：`BorderStyle=1`（纯描边）在有底色的 PPT 页上会被吃掉 → 长视频用 **`BorderStyle 3` + `BackColour &HCC000000`**。
3. **`bounds_cache.json` 的键可能是 `"1"` 也可能是 `"01"`**：直接 `cache.get("01")` 会静默取不到，**前 9 页（01~09）整页漏写字幕**。查两种写法。
4. **edge-tts 7.x 事件名是 `SentenceBoundary`，不是 `WordBoundary`**；字段 `{type, offset, duration, text}`，offset/duration 单位是 **100ns**（秒 = ÷10_000_000）。写 `WordBoundary` 永远抓不到，静默 0 条。
5. **`\q1` 不是不换行**（见上）。
6. **本机 ffmpeg 无 PDF 解码器** → 抽页图用 pymupdf（v2.0.0 已固化为 `pdf_to_pages.py`）。
7. **`zoompan` 会吃掉输入侧 `-t`**：`-loop 1 -t 3.0 -i card.png` 实际只出 2.5s → **`-t` 必须放输出侧**（`-vf` 之后）才能精确 3.0s。
8. **xfade 偏移量必须用 ffprobe 实测段时长算**（`cum - k*T`），否则报「first input is not long enough」；filter_complex 超 1400 字符就写进 `.sh` 再 `bash`，别手拼。
9. **字幕遮挡必须抽帧看**：文字密集页和结尾名片页（自带黑底白字电话条）最容易糊 —— 文字密集页用 `BorderStyle 3` 半透明底解决。
10. **滚动字幕用整页文案**，别只取 `ev[0][0]`（会变成只滚第一句）。
11. **concat `-c copy` 的片头必须带一条实长静音音轨**，且静音轨长度 ≥ 片头时长。踩法：把 `-shortest` 和 3s 片头配一条 2s 静音 → 片头被截成 2s，还不报错。正确姿势：
    ```bash
    ffmpeg -y -f lavfi -i anullsrc=channel_layout=stereo:sample_rate=44100 -t 3 -c:a aac silent.m4a   # 先单独做实长静音
    ffmpeg -y -loop 1 -i card.png -i silent.m4a -vf "zoompan=... ,format=yuv420p" \
        -c:v libx264 -preset veryfast -crf 20 -pix_fmt yuv420p -r 30 -c:a copy -t 3 intro3.mp4        # 输出侧 -t，别用 -shortest
    ```
12. **concat list 的相对路径以 list 文件所在目录为基准**。把 `file 'bench3/seg/01.mp4'` 写进 `bench3/list.txt` → 解析成 `bench3/bench3/…`，报 `Invalid argument`。**list 一律放工程根目录**，段路径写成 `bench3/seg/01.mp4`。
13. **成品画质瓶颈在「第③步烧字幕」的 CRF，不在段 CRF**。同口径 5 页样本：段 crf18 vs crf23，最终成品体积只差 7.8%（4.71 vs 4.38 MB）——第③步本来就要重编，段里的压缩被抹平了。整片第③步 crf20→crf17 体积 +21%（47.9→58.1 MB），但同帧目视几乎无差。**图文片 778 kbps 够用，别盲目压 crf 追码率数字。**
14. **Node 脚本里 `execSync` 调 ffprobe/ffmpeg 一律 EBUSY**（本机铁律）→ 量测时长体积、抽帧看图，全部走 Bash 工具；Node 只负责读文件、拼命令、写文件。
15. **【v2.0.0】PPT 直接抽页图必然跑偏**（本次升级的根因）：python-pptx 只读形状坐标，不做字体替换/自动换行/行高修正，文本框比文字小或字体缺失时排版就与 PowerPoint 不一致。**必须先转 PDF**，让排版引擎一次性把绝对坐标定死。
16. **【v2.0.0】Windows 上调 `soffice.exe` 会「退出码 0 但文件还没生成」**：`soffice.exe` 是 GUI 启动器，调用后立刻返回；`soffice.com` 才是阻塞到跑完的控制台版。`to_pdf.py` 已按 `soffice.com → soffice.exe` 顺序探测，**别改回只用 `soffice.exe`**。另外 soffice 是异步落盘，脚本还会等文件大小连续 1.2s 不变才算稳。
17. **【v2.0.0】LibreOffice 会和用户已开的实例抢 profile**：共用同一份用户配置时它直接拒绝转换（还可能返回 0）。`to_pdf.py` 用 `-env:UserInstallation=file:///<临时目录>` 起独立 profile，**转换结束必删**（体积大，留着会把工程目录撑脏）。
18. **【v2.0.0】soffice 对加密/受保护/损坏文档会「exit 0 且无产物」**：不报错但也不生成 PDF。`to_pdf.py` 专门识别这种情况并给出三条解法，而不是让它静默滑过去。
19. **【v2.0.0】`pymupdf` 与 `edge_tts` 必须同一个解释器**：分装在两个 python 里会出现「第 0 步成功、第 1 步 ModuleNotFoundError」的断链。`precheck.mjs` 会分别报出各自在哪个解释器上。
20. **【v2.0.0】中间产物 PDF 默认保留**：`pdf/source.pdf` 留着（便于复跑抽页、核对页数、回溯来源）；确认无误要清就 `to_pdf.py --clean` 或手删。**LibreOffice 的临时 profile 则是必删**，两者别搞混。

## 第 0 步失败处理（PPT→PDF）

`to_pdf.py` 对五类失败各自报错，**均不回退到"直接抽 PPT"**（那等于把跑偏问题请回来）：

| 现象 | 脚本行为 | 你该做什么 |
|---|---|---|
| 找不到 soffice | 列出探测过的路径 + 安装链接 | 装 LibreOffice；或 Office/WPS 手动另存 PDF 后 `--input x.pdf`；或 `--soffice <完整路径>` |
| soffice 非 0 退出 | 打印 stderr 尾部 600 字 | 按报错处理；常见是文件被 Office/WPS 独占锁着，先关闭 |
| 退出码 0 但无 PDF | 点明"转换没成功" | 文档多半加密/受保护/损坏，另存一份 |
| 超时（默认 300s） | 杀掉进程并报错 | 大 PPT 多图时 `--timeout 600` |
| 产出 0 页 | **删掉该产物**再报错 | 空 PDF 会让后面静默生成 0 段空视频，必须拦在前面 |

## 版本历史

| 版本 | 日期 | 变更 |
|---|---|---|
| **2.0.0** | 2026-10-07 | **重大升级（管线重构）**。① 新增第 0 步 `to_pdf.py`：PPT/Word → PDF（LibreOffice headless），排版在 PDF 环节定死，**从根上消除「画面跑偏」**；② 新增第 1 步 `pdf_to_pages.py`：PDF → 页图，取代**本机并不存在**的 `ppt-explain/doc-to-pages.mjs`，输入被钉死为 PDF；③ `precheck.mjs` 增加 soffice / pymupdf / 源 PDF / 页图四项自检（共 9 项）；④ 管线由 7 步扩为 8 步，第 2–7 步（写旁白 → 配音 → 渲染 → 字幕 → 合成 → 校验）**逻辑与参数完全未变**，已用 50 页真实 PPT 实测下游零改动跑通。 |
| 1.1.0 | 2026-10-02 | 三段式架构（段渲染 → `-c copy` 硬切 → 单遍烧字幕），50 页实测 128s → 78~93s；补齐路径参数、缺文件人话报错。 |

## 写在最后
这套东西的资产是上面 20 条踩坑 + 三段式架构 + PPT→PDF→视频输入链路，不是脚本本身。改脚本前先跑 `precheck.mjs`——大部分"跑不动"是环境问题，不是管线问题。

原始备份（`SKILL.md` + 3 个旧脚本）在 `_skill_backup/ppt-to-explainer-video-ffmpeg-bak-20261002/`。
